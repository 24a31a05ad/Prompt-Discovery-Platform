/* ============================================================
   PromptVault — Shared JavaScript
   Utilities: toast, modal, auth state, sidebar, data
   ============================================================ */

'use strict';

/* ── Mock Prompt Data ── */
const PROMPTS = [
  { id:1,  title:"Neon Cyberpunk City",      promptText:"Ultra-detailed neon cyberpunk cityscape at night, rain-slicked streets reflecting holographic billboards, flying vehicles, volumetric fog, cinematic lighting, 8K, hyperrealistic", img:"https://picsum.photos/seed/cyber1/400/300",   platform:"Midjourney",       category:"Cityscape",    style:"Cyberpunk",     isPremium:false, views:2341, copies:892,  creator:"PixelMaster", status:"approved", date:"Jan 10, 2025" },
  { id:2,  title:"Ethereal Forest Spirit",   promptText:"Ethereal forest spirit, translucent glowing form, ancient woodland, fireflies, soft bioluminescence, mystical atmosphere, concept art, artstation trending",              img:"https://picsum.photos/seed/forest2/400/300",  platform:"DALL·E 3",         category:"Fantasy",      style:"Digital Art",   isPremium:true,  views:1892, copies:234,  creator:"PixelMaster", status:"approved", date:"Jan 12, 2025" },
  { id:3,  title:"Retro Synthwave Portrait", promptText:"Retro synthwave aesthetic portrait, neon pink and purple grid horizon, chrome typography, 80s vaporwave aesthetic, high contrast, sharp edges",                         img:"https://picsum.photos/seed/synth3/400/300",   platform:"Stable Diffusion", category:"Portrait",     style:"Retro",         isPremium:false, views:3102, copies:1204, creator:"ArtVault",    status:"approved", date:"Jan 14, 2025" },
  { id:4,  title:"Ancient Dragon God",       promptText:"Ancient dragon deity, divine light emanating from scales, storm clouds, lightning, epic fantasy scale, cinematic composition, dramatic lighting, trending on artstation, unreal engine render", img:"https://picsum.photos/seed/dragon4/400/300",  platform:"Midjourney",       category:"Fantasy",      style:"Epic Fantasy",  isPremium:true,  views:4231, copies:402,  creator:"ArtVault",    status:"approved", date:"Jan 15, 2025" },
  { id:5,  title:"Minimalist Architecture",  promptText:"Minimalist brutalist architecture, concrete textures, harsh shadows, golden hour light, wide angle, architectural photography style, desaturated",                      img:"https://picsum.photos/seed/arch5/400/300",    platform:"DALL·E 3",         category:"Architecture", style:"Minimalist",    isPremium:false, views:1120, copies:567,  creator:"PixelMaster", status:"approved", date:"Jan 16, 2025" },
  { id:6,  title:"Deep Sea Bioluminescence", promptText:"Deep sea bioluminescent creatures, inky darkness, glowing tendrils, alien life forms, macro photography, ultra detailed, scientific illustration aesthetic",            img:"https://picsum.photos/seed/sea6/400/300",     platform:"Midjourney",       category:"Nature",       style:"Surreal",       isPremium:true,  views:2890, copies:189,  creator:"NovaSpark",   status:"approved", date:"Jan 17, 2025" },
  { id:7,  title:"Steampunk Inventor",       promptText:"Victorian steampunk inventor in brass workshop, clockwork mechanisms, steam pipes, leather apron, monocle, warm amber lighting, detailed props, cinematic portrait",   img:"https://picsum.photos/seed/steam7/400/300",   platform:"Stable Diffusion", category:"Portrait",     style:"Retro",         isPremium:false, views:987,  copies:421,  creator:"NovaSpark",   status:"approved", date:"Jan 18, 2025" },
  { id:8,  title:"Cosmic Library",           promptText:"Infinite cosmic library, books floating in space, galaxies between shelves, starlight reading nooks, spiral nebulae, ethereal scholar figure, surreal digital art",    img:"https://picsum.photos/seed/cosmic8/400/300",  platform:"DALL·E 3",         category:"Surreal",      style:"Surreal",       isPremium:true,  views:5023, copies:312,  creator:"PixelMaster", status:"approved", date:"Jan 19, 2025" },
  { id:9,  title:"Urban Street Photography", promptText:"Gritty urban street scene, black and white photography style, shallow depth of field, authentic street life, dramatic contrast, Leica aesthetic, documentary photography", img:"https://picsum.photos/seed/urban9/400/300",   platform:"Midjourney",       category:"Urban",        style:"Photography",   isPremium:false, views:1456, copies:678,  creator:"ArtVault",    status:"approved", date:"Jan 20, 2025" },
  { id:10, title:"Crystalline Ice Cave",     promptText:"Magical ice cave interior, crystal formations, light refractions, blues and whites, ethereal glow, fantasy environment, unreal engine quality, 4K render",            img:"https://picsum.photos/seed/ice10/400/300",    platform:"Midjourney",       category:"Nature",       style:"Epic Fantasy",  isPremium:false, views:2103, copies:891,  creator:"NovaSpark",   status:"approved", date:"Jan 21, 2025" },
  { id:11, title:"Samurai at Sunset",        promptText:"Lone samurai silhouette, crimson sunset, cherry blossoms, katana raised, cinematic composition, ink wash painting aesthetic, Studio Ghibli influence, dreamy atmosphere", img:"https://picsum.photos/seed/samurai11/400/300", platform:"DALL·E 3",         category:"Portrait",     style:"Digital Art",   isPremium:true,  views:6782, copies:523,  creator:"PixelMaster", status:"approved", date:"Jan 22, 2025" },
  { id:12, title:"Neon Jellyfish Ocean",     promptText:"Glowing neon jellyfish, deep ocean, bioluminescent trails, slow exposure photography, purple and blue tones, dreamlike underwater world, award-winning nature photography", img:"https://picsum.photos/seed/jelly12/400/300",  platform:"Stable Diffusion", category:"Nature",       style:"Surreal",       isPremium:false, views:3241, copies:1102, creator:"ArtVault",    status:"approved", date:"Jan 23, 2025" },
];

let PENDING_PROMPTS = [
  { id:101, title:"Futuristic Tokyo Night",  promptText:"Futuristic Tokyo street at night, holograms, crowds, rainy atmosphere, blade runner aesthetic, puddles reflecting neon lights", img:"https://picsum.photos/seed/pend1/400/300", platform:"Midjourney",       category:"Cityscape", style:"Cyberpunk", isPremium:false, creator:"ArtVault",  status:"pending", date:"Jan 24, 2025" },
  { id:102, title:"Desert Mirage Temple",    promptText:"Ancient desert temple revealed by mirage, surreal colors, golden sands, heat shimmer, photorealistic, ethereal glow",           img:"https://picsum.photos/seed/pend2/400/300", platform:"DALL·E 3",         category:"Architecture","style":"Surreal",    isPremium:true,  creator:"NovaSpark", status:"pending", date:"Jan 24, 2025" },
  { id:103, title:"Mech Warrior Portrait",   promptText:"Battle-worn mech warrior, close up portrait, industrial detail, rust and chrome, sci-fi concept art, octane render",           img:"https://picsum.photos/seed/pend3/400/300", platform:"Stable Diffusion", category:"Portrait",  style:"Cyberpunk", isPremium:false, creator:"PixelMaster", status:"pending", date:"Jan 25, 2025" },
];

/* ── Auth State ── */
let APP = {
  user: null,
  role: 'guest', // guest | free | starter | pro | premium | creator | admin
  copies: 0,
  views: 0,
  saved: [],
};

const DEMO_ACCOUNTS = {
  'admin@demo.com':   'admin',
  'creator@demo.com': 'creator',
  'premium@demo.com': 'premium',
  'user@demo.com':    'free',
};

const PLAN_LIMITS = {
  guest:   { copies: 0,   views: 9 },
  free:    { copies: 5,   views: 9 },
  starter: { copies: 20,  views: Infinity },
  pro:     { copies: 60,  views: Infinity },
  premium: { copies: 150, views: Infinity },
  creator: { copies: 999, views: Infinity },
  admin:   { copies: 999, views: Infinity },
};

const PLAN_ICONS  = { free:'👤', starter:'🟢', pro:'🔵', premium:'💎', creator:'✍️', admin:'🛡️', guest:'👤' };
const PLAN_NAMES  = { free:'Free Plan', starter:'Starter · ₹99/mo', pro:'Pro · ₹149/mo', premium:'Premium · ₹249/mo', creator:'Creator', admin:'Admin' };
const ROLE_ROUTES = { admin:'/pages/admin.html', creator:'/pages/creator.html', free:'/pages/dashboard.html', starter:'/pages/dashboard.html', pro:'/pages/dashboard.html', premium:'/pages/dashboard.html' };

/* ── Helpers ── */
function getLimits() { return PLAN_LIMITS[APP.role] || PLAN_LIMITS.free; }
function canAccessPremium() { return ['pro','premium','admin'].includes(APP.role); }
function canSave() { return ['starter','pro','premium','admin'].includes(APP.role); }
function showAds() { return ['free','creator','guest'].includes(APP.role); }
function isAdmin() { return APP.role === 'admin'; }
function isCreator() { return ['creator','admin'].includes(APP.role); }

/* ── Load / Save app state to sessionStorage ── */
function saveState() {
  sessionStorage.setItem('pv_app', JSON.stringify({ user: APP.user, role: APP.role, copies: APP.copies, views: APP.views, saved: APP.saved }));
}
function loadState() {
  try {
    const s = JSON.parse(sessionStorage.getItem('pv_app'));
    if (s) { APP.user = s.user; APP.role = s.role; APP.copies = s.copies || 0; APP.views = s.views || 0; APP.saved = s.saved || []; }
  } catch(_) {}
}

/* ── Toast ── */
function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  if (!c) return;
  const t = document.createElement('div');
  t.className = `toast ${type} slide-up`;
  const icons = { success:'✅', error:'❌', info:'ℹ️' };
  t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span style="flex:1">${msg}</span><button class="toast-x" onclick="this.parentElement.remove()">×</button>`;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 3400);
}

/* ── Navbar ── */
function initNavbar() {
  loadState();
  const actions = document.getElementById('nav-actions');
  if (!actions) return;
  if (APP.user) {
    const dashPath = APP.role === 'admin' ? 'pages/admin.html' : APP.role === 'creator' ? 'pages/creator.html' : 'pages/dashboard.html';
    actions.innerHTML = `
      <span style="font-size:12px;color:var(--ink3)">${PLAN_ICONS[APP.role]||''} ${APP.user.name?.split(' ')[0]||''}</span>
      <a href="${dashPath}" class="btn btn-ghost btn-sm">Dashboard</a>
      <button class="btn btn-outline btn-sm" onclick="doLogout()">Logout</button>`;
  } else {
    actions.innerHTML = `
      <a href="pages/login.html" class="btn btn-ghost btn-sm">Login</a>
      <a href="pages/signup.html" class="btn btn-primary btn-sm">Sign Up Free</a>`;
  }
  // Mark active nav link
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(a => {
    if (a.href && path.includes(a.getAttribute('href')?.replace('../','').replace('.html',''))) a.classList.add('active');
  });
}

/* ── Logout ── */
function doLogout() {
  APP = { user: null, role: 'guest', copies: 0, views: 0, saved: [] };
  saveState();
  toast('Logged out successfully', 'info');
  setTimeout(() => window.location.href = '../index.html', 800);
}

/* ── Prompt Card HTML ── */
function promptCardHTML(p, showLock) {
  const locked = p.isPremium && !canAccessPremium() && showLock;
  return `
  <div class="card pc fade-in" onclick="openModal(${p.id})">
    <div class="pc-img">
      <img src="${p.img}" alt="${p.title}" loading="lazy" onerror="this.style.display='none'"/>
      ${locked ? `<div class="pc-lock"><div class="pc-lock-icon">🔒</div><span style="font-weight:700;font-size:13px;color:var(--ink2)">Premium</span><span style="font-size:11px;color:var(--ink3)">Upgrade to unlock</span></div>` : ''}
      <div class="pc-top-badges">
        <span class="badge ${p.isPremium ? 'badge-premium' : 'badge-free'}">${p.isPremium ? '⭐ Premium' : 'Free'}</span>
      </div>
      <div class="pc-platform-tag">${p.platform}</div>
    </div>
    <div class="pc-body">
      <div class="pc-title">${p.title}</div>
      <div class="pc-desc">${p.promptText}</div>
      <div class="pc-foot">
        <div class="pc-stats"><span>👁 ${p.views.toLocaleString()}</span><span>📋 ${p.copies.toLocaleString()}</span></div>
        <span class="creator">${p.creator}</span>
      </div>
    </div>
  </div>`;
}

/* ── Modal ── */
let currentPrompt = null;

function openModal(id) {
  const p = PROMPTS.find(x => x.id === id);
  if (!p) return;
  const lim = getLimits();
  if (APP.views >= lim.views && lim.views !== Infinity) {
    toast(`Daily view limit reached (${lim.views}/day). Upgrade for more!`, 'error');
    return;
  }
  APP.views++;
  saveState();
  currentPrompt = p;

  const locked = p.isPremium && !canAccessPremium();
  document.getElementById('m-img').src = p.img;
  document.getElementById('m-img').style.filter = locked ? 'blur(14px)' : 'none';
  document.getElementById('m-blur').style.display = locked ? 'flex' : 'none';
  document.getElementById('m-title').textContent = p.title;
  document.getElementById('m-creator').textContent = 'by ' + p.creator + ' · ' + p.platform;
  document.getElementById('m-prompt').textContent = p.promptText;
  document.getElementById('m-prompt').style.filter = locked ? 'blur(5px)' : 'none';
  document.getElementById('m-style').textContent = p.style;
  document.getElementById('m-platform').textContent = p.platform;
  document.getElementById('m-category').textContent = p.category;
  document.getElementById('m-views').textContent = p.views.toLocaleString();
  document.getElementById('m-badges').innerHTML = `<span class="badge ${p.isPremium ? 'badge-premium' : 'badge-free'}">${p.isPremium ? '⭐ Premium' : 'Free'}</span>`;
  const saveBtn = document.getElementById('m-save-btn');
  if (saveBtn) saveBtn.textContent = APP.saved.includes(id) ? '❤️' : '🤍';

  const hint = document.getElementById('m-hint');
  if (hint) {
    if (!APP.user) {
      hint.style.display = '';
      hint.innerHTML = '✦ <a href="pages/signup.html">Sign up free</a> to copy & save prompts · <a href="pages/pricing.html">Upgrade</a> for premium access';
    } else if (locked) {
      hint.style.display = '';
      hint.innerHTML = '🔒 <a href="pages/pricing.html">Upgrade to Pro or Premium</a> to unlock this prompt';
    } else {
      hint.style.display = 'none';
    }
  }
  document.getElementById('prompt-modal').classList.add('open');
}

function closeModal() {
  document.getElementById('prompt-modal')?.classList.remove('open');
  currentPrompt = null;
}

function doCopy() {
  if (!currentPrompt) return;
  if (!APP.user) { toast('Sign in to copy prompts', 'error'); return; }
  if (currentPrompt.isPremium && !canAccessPremium()) { toast('Upgrade to Pro or Premium to copy premium prompts', 'error'); return; }
  const lim = getLimits();
  if (APP.copies >= lim.copies) { toast(`Daily copy limit reached (${lim.copies}/day). Upgrade for more!`, 'error'); return; }
  navigator.clipboard?.writeText(currentPrompt.promptText).catch(() => {});
  APP.copies++;
  saveState();
  const btn = document.getElementById('m-copy-btn');
  if (btn) { btn.textContent = '✓ Copied!'; setTimeout(() => btn.textContent = '📋 Copy Prompt', 2000); }
  toast('Prompt copied to clipboard! ✓', 'success');
}

function doSave() {
  if (!APP.user) { toast('Sign in to save prompts', 'error'); return; }
  if (!canSave()) { toast('Upgrade to Starter or above to save prompts', 'error'); return; }
  if (!currentPrompt) return;
  const id = currentPrompt.id;
  const idx = APP.saved.indexOf(id);
  const btn = document.getElementById('m-save-btn');
  if (idx > -1) {
    APP.saved.splice(idx, 1);
    toast('Removed from saved', 'info');
    if (btn) btn.textContent = '🤍';
  } else {
    APP.saved.push(id);
    toast('Saved! ❤️', 'success');
    if (btn) btn.textContent = '❤️';
  }
  saveState();
}

/* ── Sidebar Builder ── */
function buildSidebar(role, activePage) {
  const el = document.getElementById('sidebar');
  if (!el) return;
  const userItems    = [['pages/dashboard.html','📊','Dashboard'],['pages/explore.html','🔍','Explore Prompts'],['pages/saved.html','❤️','Saved Prompts'],['pages/account.html','⚙️','Account']];
  const creatorItems = [['pages/creator.html','📊','Dashboard'],['pages/upload.html','📤','Upload Prompt'],['pages/my-prompts.html','🗂️','My Prompts']];
  const adminItems   = [['pages/admin.html','📊','Dashboard'],['pages/admin-review.html','🛂','Review Prompts'],['pages/admin-users.html','👥','Users'],['pages/admin-stats.html','📈','Stats']];
  const items = role === 'admin' ? adminItems : role === 'creator' ? creatorItems : userItems;
  const label = { admin: 'Admin Panel', creator: 'Creator Panel' }[role] || 'User Panel';

  el.innerHTML = `
    <div class="sidebar-logo-area">
      <a href="../index.html" class="s-logo">Prompt<em>Vault</em></a>
      <div class="sidebar-role-tag">${label}</div>
    </div>
    <nav class="sidebar-nav">
      ${items.map(([path, icon, lbl]) => `
        <a href="../${path}" class="sidebar-item ${activePage === path ? 'active' : ''}">
          <span class="si">${icon}</span>${lbl}
        </a>`).join('')}
    </nav>
    <div class="sidebar-foot">
      <button class="btn btn-ghost btn-sm btn-full" onclick="doLogout()" style="justify-content:flex-start;gap:8px">🚪 Logout</button>
    </div>`;
}

/* ── Shared Modal HTML (injected into pages that need it) ── */
const MODAL_HTML = `
<div class="modal-overlay" id="prompt-modal" onclick="if(event.target===this)closeModal()">
  <div class="modal-box pop-in">
    <div class="modal-grid">
      <div class="modal-img-side">
        <img id="m-img" src="" alt=""/>
        <div class="modal-blur-wall" id="m-blur" style="display:none">
          <div style="font-size:36px">🔒</div>
          <p style="font-family:'Playfair Display',serif;font-size:18px;font-weight:700">Premium Prompt</p>
          <p style="font-size:13px;color:var(--ink3);margin-bottom:12px">Unlock with Pro or Premium plan</p>
          <a href="pricing.html" class="btn btn-primary btn-sm">Upgrade Now</a>
        </div>
        <div style="position:absolute;top:12px;left:12px;display:flex;gap:6px" id="m-badges"></div>
      </div>
      <div class="modal-info">
        <div>
          <div class="modal-title" id="m-title"></div>
          <p id="m-creator" style="font-size:12px;color:var(--ink3);margin-top:5px"></p>
        </div>
        <div>
          <div class="field-label" style="margin-bottom:8px">Prompt Text</div>
          <div class="prompt-text-box" id="m-prompt"></div>
        </div>
        <div class="modal-meta-row">
          <div class="meta-box"><div class="meta-label">Style</div><div class="meta-val" id="m-style"></div></div>
          <div class="meta-box"><div class="meta-label">Platform</div><div class="meta-val" id="m-platform"></div></div>
          <div class="meta-box"><div class="meta-label">Category</div><div class="meta-val" id="m-category"></div></div>
          <div class="meta-box"><div class="meta-label">Views</div><div class="meta-val" id="m-views"></div></div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-primary" id="m-copy-btn" onclick="doCopy()">📋 Copy Prompt</button>
          <button class="btn btn-ghost" id="m-save-btn" onclick="doSave()" style="min-width:48px">🤍</button>
          <button class="btn btn-ghost" onclick="closeModal()" style="min-width:48px">✕</button>
        </div>
        <div class="hint-box" id="m-hint" style="display:none"></div>
      </div>
    </div>
  </div>
</div>
<div id="toast-container"></div>`;

function injectModal() {
  const div = document.createElement('div');
  div.innerHTML = MODAL_HTML;
  document.body.appendChild(div);
}

/* ── Auto-init on load ── */
document.addEventListener('DOMContentLoaded', () => {
  loadState();
  initNavbar();
});
